from .mandel import compute_mandelbrot
